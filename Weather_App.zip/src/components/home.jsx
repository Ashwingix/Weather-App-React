import  '../styles/home.css';
import Weather from './weather';
const Home = () => {
    return ( 
        <div className="home">
            
            <Weather/>
        </div>
     );
}
 
export default Home;